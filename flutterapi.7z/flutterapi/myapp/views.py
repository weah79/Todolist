from django.shortcuts import render
from django.http import JsonResponse

from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from .serializers import TodolistSerializer
from .models import Todolist

# Get Data
@api_view(['GET'])
def all_todolist(request):
    alltodolist = Todolist.objects.all() # Retrieve all data
    serializer = TodolistSerializer(alltodolist, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['POST'])
def post_todolist(request):
    if request.method == 'POST':
        serializer = TodolistSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_NOT_FOUND)        
        

@api_view(['PUT'])
def update_todolist(request,TID):
    todo = Todolist.objects.get(id=TID)
    if request.method == 'PUT':
        data = {}
        serializer = TodolistSerializer(todo, data=request.data)
        if serializer.is_valid():
            serializer.save()
            data['status'] = 'updated'
            return Response(data=data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_NOT_FOUND)      

@api_view(['DELETE'])
def delete_todolist(request,TID):
    todo = Todolist.objects.get(id=TID)
    if request.method == 'DELETE':        
        delete = todo.delete()
        data = {}        
        if delete:
            data['status'] = 'deleted'
            statuscode = status.HTTP_200_OK
        else:
            data['status'] = 'failed'
            statuscode = status.HTTP_400_NOT_FOUND     
        
        return Response(data=data, status=statuscode)    
        


data = [
    {
        "title": "VS Code",
        "subtitle": "เครื่องมือสำหรับพัฒนาเเอพพลิเคชั่น รองรับหลายภาษา เช่น Flutter, Python",
        "image_url": "https://raw.githubusercontent.com/weah79/BasicAPI/main/VS_Code.jpg",
        "detail": "เป็นโปรแกรมจากบริษัทไมโครซอฟต์ เป็นประเภท Editor ใช้ในการแก้ไขโค้ดที่มีขนาดเล็ก แต่มีประสิทธิภาพสูง เป็น OpenSource โปรแกรมจึงสามารถนำมาใช้งานได้โดยไม่มีค่าใช้จ่าย เหมาะสำหรับนักพัฒนาโปรแกรมที่ต้องการใช้งานหลายแพลตฟอร์ม รองรับการใช้งานทั้งบน  Windows ,  macOS และ  Linux  รองรับหลายภาษาทั้ง  JavaScript, TypeScript และ Node.js ในตัว และสามารถเชื่อมต่อกับ  Git ได้ง่าย สามารถนำมาใช้งานได้ง่ายไม่ซับซ้อน มีเครื่องมือและส่วนขยายต่าง ๆ ให้เลือกใช้มากมาย รองรับการเปิดใช้งานภาษาอื่น ๆ ทั้ง ภาษา  C++ ,  C# ,  Java ,  Python ,  PHP  หรือ  Go  สามารถปรับเปลี่ยน Themes  ได้  มีส่วน Debugger  และ Commands  เป็นต้น"
    },
    {
        "title": "Docker Container",
        "subtitle": "แพลตฟอร์มซอฟต์แวร์ที่ช่วยให้คุณสร้าง และทดสอบ แอพพลิเคชันได้อย่างรวดเร็ว",
        "image_url": "https://raw.githubusercontent.com/weah79/BasicAPI/main/Docker.jpg",
        "detail": "Docker จะบรรจุซอฟต์แวร์ลงไปในหน่วยที่เป็นมาตรฐานเรียกว่า คอนเทนเนอร์ ซึ่งจะมีทุกสิ่งที่ซอฟต์แวร์ต้องใช้ในการเรียกใช้งาน รวมทั้งไลบรารี เครื่องมือสำหรับระบบ โค้ด และรันไทม์ เมื่อใช้ Docker คุณจะสามารถติดตั้งใช้จริงและปรับขนาดแอปพลิเคชันให้เหมาะกับทุกสภาพแวดล้อมและทราบว่าโค้ดของคุณจะเรียกใช้ได้อย่างอย่างรวดเร็ว"
    },
    {
        "title": "StackOverflow",
        "subtitle": "เวบไซค์ช่วยในการค้นหาเมื่อพบปัญหาในการเขียนโปรแกรม",
        "image_url": "https://raw.githubusercontent.com/weah79/BasicAPI/main/StackOverflow.jpg",
        "detail": "คือ เวบไซค์เพื่อถามและตอบปัญหาของโปรแกรมเมอร์ ถ้าตั้งคำถาม และ อธิบายปัญหาอย่างละเอียดชัดเจน ให้ข้อมูลครับถ้วน อาจจะได้คำตอบ และ วิธีการแก้ไขปัญหาภายในเวลาไม่ถึงชั่วโมง"
    }
]

def Home(request):
    return JsonResponse(data=data,safe=False, json_dumps_params={'ensure_ascii': False});
